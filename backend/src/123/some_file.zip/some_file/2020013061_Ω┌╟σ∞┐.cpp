#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <cstdio>
#include <vector>
#include <sstream>
using namespace std;
int v, e, n;
int begin_node, end_node;

struct edge {
	int len;
	int node;
};

struct vertex {
	vector<edge> succ_vertexes;
	int data;
};

vector<vertex> vertexes;
int in_vertex[101] = { 0 }, in_edge[201] = { 0 };
int in_len[201] = { 0 };
vector<int> line;
//vector<string> ans;

struct table {
	int length;
	int fore;
	bool isDone = false;
	table(int a, int b) {
		length = a;
		fore = b;
	}
};

void dijstra(int begin, int end) {
	vector<table*> path;
	for (int i = 0; i < v; i++) {
		path.push_back(new table(99999, -1));
	}
	int nex = begin;
	path[nex]->length = 0;
	while (nex != -1) {
		path[nex]->isDone = true;
		int nn = vertexes[nex].succ_vertexes.size();
		for (int i = 0; i < nn; i++) {
			if (path[vertexes[nex].succ_vertexes[i].node]->length > vertexes[nex].succ_vertexes[i].len + path[nex]->length) {
				path[vertexes[nex].succ_vertexes[i].node]->length = vertexes[nex].succ_vertexes[i].len + path[nex]->length;
				path[vertexes[nex].succ_vertexes[i].node]->fore = nex;
			}
		}
		int min = 99999;
		nex = -1;
		for (int i = 0; i < v; i++) {
			if (path[i]->isDone == false) {
				if (path[i]->length < min) {
					nex = i;
					min = path[i]->length;
				}
			}
		}
		if (nex == end) {
			break;
		}
	}
	if (nex == -1) {
		printf("NO PATH\n");
		return;
	}
	int path_len = 0;
	int cc = end;
	line.clear();
	while (cc != begin) {
		line.push_back(cc);
		cc = path[cc]->fore;
	}
	line.push_back(cc);
	string ans;
	ans = ans + "[";
	for (int i = line.size()-1; i >= 1; i--) {
		std::stringstream ss;
		ss << line[i];
		ans = ans + ss.str() + "->";
	}
	std::stringstream ss;
	ss << line[0];
	ans += ss.str();
	ans += " ";
	std::stringstream ss1;
	ss1 << path[end]->length;
	ans += ss1.str();
	ans += "]";
	cout << ans << endl;
}

int main() {
	scanf("%d%d", &v, &e);
	for (int i = 0; i <= v; i++) {
		scanf("%d", &in_vertex[i]);
	}
	for (int i = 0; i < e; i++) {
		scanf("%d", &in_edge[i]);
	}
	for (int i = 0; i < e; i++) {
		scanf("%d", &in_len[i]);
	}
	int aa, bb;
	for (int i = 0; i < v; i++) {
		aa = in_vertex[i];
		if (i == v - 1) {
			bb = e - 1;
		}
		else {
			bb = in_vertex[i + 1] - 1;
		}
		vertex new_v;
		new_v.data = i;
		for (int j = aa; j <= bb; j++) {
			edge new_edge;
			new_edge.len = in_len[j];
			new_edge.node = in_edge[j];
			new_v.succ_vertexes.push_back(new_edge);
		}
		vertexes.push_back(new_v);
	}
	scanf("%d", &n);
	for (int i = 0; i < n; i++) {
		scanf("%d%d", &begin_node, &end_node);
		dijstra(begin_node, end_node);
	}
	return 0;
}